﻿namespace EuroMonitor.BookOnline.Domain.Models;

public class BookFilter
{
    public long  Id { get; set; }
    public string Name { get; set; }
    public string Text { get; set; }
    public int CurrentPage { get; set; } = 1;
    public int PageSize { get; set; } = 10;
    public string OrderBy { get; set; } = "name";
    public string SortBy { get; set; } = "asc";
}