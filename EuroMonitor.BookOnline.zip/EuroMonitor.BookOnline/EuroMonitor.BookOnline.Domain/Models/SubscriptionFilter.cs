﻿using EuroMonitor.BookOnline.Domain.Entities;

namespace EuroMonitor.BookOnline.Domain.Models;

public class SubscriptionFilter
{
    public long Id { get; set; }
    public long UserId { get; set; }
    public long BookId { get; set; }
    //public virtual ICollection<Catalog> Catalogs { get; set; }
   public int CurrentPage { get; set; } = 1;
    public int PageSize { get; set; } = 10;
    public string OrderBy { get; set; } = "UserId";
    public string SortBy { get; set; } = "asc";
}