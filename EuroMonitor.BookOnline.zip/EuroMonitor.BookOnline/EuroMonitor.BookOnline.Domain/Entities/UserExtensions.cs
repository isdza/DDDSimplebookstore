﻿

using System.ComponentModel.DataAnnotations;
using System.Text.RegularExpressions;

namespace EuroMonitor.BookOnline.Domain.Entities;

public static class UserExtensions
{
    public static string GetFullName(this User user)
    {
        return $"{user.FirstName} {user.Surname}";
    }
      

    public static void ValidatePassword(this User user)
    {
        if (string.IsNullOrEmpty(user.Password))
            throw new ValidationException("The Password is required.");

        const string regex =
            @"^((?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])|(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[^a-zA-Z0-9])|(?=.*?[A-Z])(?=.*?[0-9])(?=.*?[^a-zA-Z0-9])|(?=.*?[a-z])(?=.*?[0-9])(?=.*?[^a-zA-Z0-9])).{8,}$";

        if (!Regex.IsMatch(user.Password, regex))
            throw new ValidationException(
                "Password must be at least 8 characters and contain at 3 of the following: upper case (A-Z), lower case (a-z), number (0-9) and special character (e.g. !@#$%^&*).");
    }

    public static void ValidateEmail(this User user)
    {
        if (string.IsNullOrEmpty(user.Email))
            throw new ValidationException("The Email is required.");

        if (!Regex.IsMatch(user.Email,
                @"\A(?:[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?)\Z",
                RegexOptions.IgnoreCase))
            throw new ValidationException("The Email is not a valid e-mail address.");
    }

    public static void ValidateSurname(this User user)
    {
        if (string.IsNullOrEmpty(user.Surname))
            throw new ValidationException("The Surname is required.");

        if (user.Surname.Length < 2 || user.Surname.Length > 100)
            throw new ValidationException(
                "The Surname must be a string with a minimum length of 2 and a maximum length of 100.");
    }

    public static void ValidateFirstName(this User user)
    {
        if (string.IsNullOrEmpty(user.FirstName))
            throw new ValidationException("The First Name is required.");

        if (user.FirstName.Length < 2 || user.FirstName.Length > 100)
            throw new ValidationException(
                "The First Name must be a string with a minimum length of 2 and a maximum length of 100.");
    }
}