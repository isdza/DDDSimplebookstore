﻿ namespace EuroMonitor.BookOnline.Domain.Entities
{

    public class Book
    {
        public long Id { get; set; }
        public string Name { get; set; }
        public string Text { get; set; }
       
    }
}