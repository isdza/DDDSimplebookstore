﻿ 
namespace EuroMonitor.BookOnline.Domain.Entities;
 
public class Subscription
{
    public long Id { get; set; }
    public long UserId { get; set; }
    public long BookId { get; set; }

     
  //  public virtual ICollection<Catalog> Catalogs { get; set; }


}

 