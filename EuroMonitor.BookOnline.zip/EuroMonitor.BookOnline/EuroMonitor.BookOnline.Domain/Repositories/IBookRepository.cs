﻿
using EuroMonitor.BookOnline.Domain.Entities;
using EuroMonitor.BookOnline.Domain.Models;

namespace EuroMonitor.BookOnline.Domain.Repositories;


public interface IBookRepository : IRepositoryBase<Book>
{
    
    Task<int> CountByFilterAsync(BookFilter filter);
    Task<Book> GetByFilterAsync(BookFilter filter);
    Task<List<Book>> GetListByFilterAsync(BookFilter filter);
}
    


