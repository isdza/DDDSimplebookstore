﻿
using EuroMonitor.BookOnline.Domain.Entities;
using EuroMonitor.BookOnline.Domain.Models;

namespace EuroMonitor.BookOnline.Domain.Repositories;


public interface ISuscriptionRepository : IRepositoryBase<Subscription>
{ 
    Task<int> CountByFilterAsync(SubscriptionFilter filter);
    Task<Subscription> GetByFilterAsync(SubscriptionFilter filter);
    Task<List<Subscription>> GetListByFilterAsync(SubscriptionFilter filter);

}
 