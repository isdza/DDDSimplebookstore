﻿
namespace EuroMonitor.BookOnline.Domain.Repositories;
  
public interface IRepositoryBase<TEntity> : IDisposable where TEntity : class
{
     
    Task AddAsync(TEntity entity);

    void Add(TEntity entity);
    Task<TEntity> GetByIdAsync(long id);
    Task<IList<TEntity>> GetAllAsync();
    //void Update(TEntity entity);
    //void Remove(TEntity entity);
    Task<int> SaveChangesAsync();
}