﻿
using EuroMonitor.BookOnline.Domain.Entities;
using EuroMonitor.BookOnline.Domain.Models;

namespace EuroMonitor.BookOnline.Domain.Repositories;


public interface IUserRepository :IRepositoryBase<User>
{
    
    Task<int> CountByFilterAsync(UserFilter filter);
    Task<User> GetByFilterAsync(UserFilter filter);
    Task<List<User>> GetListByFilterAsync(UserFilter filter);
}
    


