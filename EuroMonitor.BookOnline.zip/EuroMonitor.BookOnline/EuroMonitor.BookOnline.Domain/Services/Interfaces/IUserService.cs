﻿using EuroMonitor.BookOnline.Domain.Entities;
using EuroMonitor.BookOnline.Domain.Models;

namespace EuroMonitor.BookOnline.Domain.Interfaces;

public interface IUserService
{
    Task<Pagination<User>> GetListByFilterAsync(UserFilter filter);
    Task<User> GetByFilterAsync(UserFilter filter);

  //  Task<IEnumerable<User>> GetAllAsync();


    Task<long> CreateAsync(User  user);
    
}