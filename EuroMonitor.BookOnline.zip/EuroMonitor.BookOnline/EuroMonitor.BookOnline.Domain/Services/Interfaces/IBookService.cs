﻿using EuroMonitor.BookOnline.Domain.Entities;
using EuroMonitor.BookOnline.Domain.Models;

namespace EuroMonitor.BookOnline.Domain.Interfaces;

public interface IBookService
{
   
   
    Task<IList<Book>> GetAllAsync();
    Task<Book> GetByFilterAsync(BookFilter filter);


}