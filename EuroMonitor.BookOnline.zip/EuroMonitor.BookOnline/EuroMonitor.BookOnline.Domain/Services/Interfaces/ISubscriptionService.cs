﻿using EuroMonitor.BookOnline.Domain.Entities;
using EuroMonitor.BookOnline.Domain.Models;

namespace EuroMonitor.BookOnline.Domain.Interfaces;

public interface ISubscriptionService
{
    Task<Pagination<Subscription>> GetListByFilterAsync(SubscriptionFilter filter);
    Task<Subscription> GetByFilterAsync(SubscriptionFilter filter);

    //Task<int> CreateAsync(Subscription user);


}