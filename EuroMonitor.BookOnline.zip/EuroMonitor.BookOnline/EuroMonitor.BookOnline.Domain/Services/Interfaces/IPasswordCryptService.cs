﻿
namespace EuroMonitor.BookOnline.Domain.Services.Interfaces;
 
public interface IPasswordCryptService
{
    string Hash(string password);

    (bool Verified, bool NeedsUpgrade) Check(string hash, string password);
}