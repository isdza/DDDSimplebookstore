﻿
using EuroMonitor.BookOnline.Domain.Entities;
using EuroMonitor.BookOnline.Domain.Interfaces;
using EuroMonitor.BookOnline.Domain.Models;
using EuroMonitor.BookOnline.Domain.Repositories;
using EuroMonitor.BookOnline.Domain.Services.Interfaces;
using System.ComponentModel.DataAnnotations;

namespace EuroMonitor.BookOnline.Domain.Services;

public class UserService : IUserService
{
    private readonly IUserRepository  _userRepository;
    private readonly IPasswordCryptService  _passwordCryptService;

    public UserService(IUserRepository  userRepository, IPasswordCryptService passwordCryptService)
    {
        _userRepository = userRepository;
        _passwordCryptService = passwordCryptService;
    }

    public async Task<Pagination<User>> GetListByFilterAsync(UserFilter filter)
    {
        if (filter == null)
            throw new ValidationException("Filter is null.");

        if (filter.PageSize > 100)
            throw new ValidationException("Maximum allowed page size is 100.");

        if (filter.CurrentPage <= 0) filter.PageSize = 1;

        var total = await _userRepository.CountByFilterAsync(filter);

        if (total == 0) return new Pagination<User>();

        var paginateResult = await _userRepository.GetListByFilterAsync(filter);

        var result = new Pagination<User>
        {
            Count = total,
            CurrentPage = filter.CurrentPage,
            PageSize = filter.PageSize,
            Result = paginateResult.ToList()
        };

        return result;
    }

    public async Task<User> GetByFilterAsync(UserFilter filter)
    {
        if (filter == null)
            throw new ValidationException("Filter is null.");

        return await _userRepository.GetByFilterAsync(filter);
    }

    public async Task<long> CreateAsync(User  user)
    {
        if (user == null)
            throw new ValidationException("user is null.");

        Validate(user);

        var isAvailableEmail = await IsAvailableEmailAsync(user.Email);
        if (!isAvailableEmail) throw new ValidationException("Email is not available.", new ValidationException());

       // user.Password = _passwordCryptService.Hash(user.Password);
        
        _userRepository.Add(user);
        await _userRepository.SaveChangesAsync();

        return user.Id;
    }
     
    public async Task<bool> IsAvailableEmailAsync(string email)
    {
        var existingEmail = await _userRepository.GetByFilterAsync(new UserFilter { Email = email });
        return existingEmail == null;
    }

    private static void Validate(User user)
    {
        user.ValidateFirstName();

        user.ValidateSurname();

        user.ValidateEmail();

        user.ValidatePassword();
    }
}