﻿
using EuroMonitor.BookOnline.Domain.Entities;
using EuroMonitor.BookOnline.Domain.Interfaces;
using EuroMonitor.BookOnline.Domain.Models;
using EuroMonitor.BookOnline.Domain.Repositories;
 
using System.ComponentModel.DataAnnotations;

namespace EuroMonitor.BookOnline.Domain.Services;

public class SubscriptionService : ISubscriptionService
{
    private readonly ISuscriptionRepository _suscriptionRepository;


    public SubscriptionService(ISuscriptionRepository suscriptionRepository)
    {
        _suscriptionRepository = suscriptionRepository;

    }

    public async Task<Pagination<Subscription>> GetListByFilterAsync(SubscriptionFilter filter)
    {
        if (filter == null)
            throw new ValidationException("Filter is null.");

        if (filter.PageSize > 100)
            throw new ValidationException("Maximum allowed page size is 100.");

        if (filter.CurrentPage <= 0) filter.PageSize = 1;

        var total = await _suscriptionRepository.CountByFilterAsync(filter);

        if (total == 0) return new Pagination<Subscription>();

        var paginateResult = await _suscriptionRepository.GetListByFilterAsync(filter);

        var result = new Pagination<Subscription>
        {
            Count = total,
            CurrentPage = filter.CurrentPage,
            PageSize = filter.PageSize,
            Result = paginateResult.ToList()
        };

        return result;
    }

    public async Task<Subscription> GetByFilterAsync(SubscriptionFilter filter)
    {
        if (filter == null)
            throw new ValidationException("Filter is null.");

        return await _suscriptionRepository.GetByFilterAsync(filter);
    }
}

        
        

         
