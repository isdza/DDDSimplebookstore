﻿
using EuroMonitor.BookOnline.Domain.Entities;
using EuroMonitor.BookOnline.Domain.Interfaces;
using EuroMonitor.BookOnline.Domain.Models;
using EuroMonitor.BookOnline.Domain.Repositories;
using EuroMonitor.BookOnline.Domain.Services.Interfaces;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace EuroMonitor.BookOnline.Domain.Services;

public class BookService : IBookService
{
    private readonly IBookRepository  _bookRepository;
   
    public BookService(IBookRepository  bookRepository )
    {
        _bookRepository = bookRepository;
        
    }

 
    public async Task<IList<Book>> GetAllAsync()
    {
       
        return await _bookRepository.GetAllAsync();
    }
    public async Task<Book> GetByFilterAsync(BookFilter filter)
    {
        if (filter == null)
            throw new ValidationException("Filter is null.");

        return await _bookRepository.GetByFilterAsync(filter);
    }

}