﻿
namespace EuroMonitor.BookOnline.Application.Dtos;

public class SubscriptionFilterDto
{
    public long Id { get; set; }
    
    public long UserId { get; set; }
    public long BookId { get; set; }
    
     
    public int CurrentPage { get; set; } = 1;
    public int PageSize { get; set; } = 10;
    public string OrderBy { get; set; } = "Name";
    public string SortBy { get; set; } = "asc";
}