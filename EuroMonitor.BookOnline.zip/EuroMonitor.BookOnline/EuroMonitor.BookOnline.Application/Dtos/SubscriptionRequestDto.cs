﻿
using EuroMonitor.BookOnline.Domain.Entities;

namespace EuroMonitor.BookOnline.Application.Dtos;

public class SubscriptionRequestDto
{


    // public int Id { get; set; }
   
    public long UserId { get; set; }
    public long BookId { get; set; }
     
     
}