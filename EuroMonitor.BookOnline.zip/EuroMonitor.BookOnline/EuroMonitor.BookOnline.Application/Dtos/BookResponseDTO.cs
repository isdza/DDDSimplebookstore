﻿
using Newtonsoft.Json;

namespace EuroMonitor.BookOnline.Application.Dtos;


public class BookResponseDTo
{
    public long Id { get; set; }
    public string Name { get; set; }
    public string Text { get; set; }
}