﻿using EuroMonitor.BookOnline.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EuroMonitor.BookOnline.Application.Dtos
{
    public class SubscriptionResponseDto
    {
        public long Id { get; set; }
        public long UserId { get; set; }
        public long BookId { get; set; }
       // public virtual ICollection<Catalog> Catalogs { get; set; }
        public int CurrentPage { get; set; } = 1;
        public int PageSize { get; set; } = 10;
        public string OrderBy { get; set; } = "customerId";
        public string SortBy { get; set; } = "asc";
    }
}
