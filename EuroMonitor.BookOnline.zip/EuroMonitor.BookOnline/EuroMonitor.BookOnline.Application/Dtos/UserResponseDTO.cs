﻿
using Newtonsoft.Json;

namespace EuroMonitor.BookOnline.Application.Dtos;


public class UserResponseDTo
{
     
    public long Id { get; set; }

     
    public string FirstName { get; set; }
    
    public string Surname { get; set; }

    
    public string Email { get; set; }
}