﻿using AutoMapper;
using EuroMonitor.BookOnline.Application.Dtos;
using EuroMonitor.BookOnline.Application.Facades.Interfaces;
using EuroMonitor.BookOnline.Domain.Entities;
using EuroMonitor.BookOnline.Domain.Interfaces;
using EuroMonitor.BookOnline.Domain.Models;
 

namespace EuroMonitor.BookOnline.Application.Facades;

public class UserFacade : IUserFacade
{
    private readonly IUserService _userService;
    private readonly IMapper _mapper;

    public UserFacade(IUserService userService, IMapper mapper)
    {
        _userService = userService;
        _mapper = mapper;
    }

    public async Task<PaginationDto<UserResponseDTo>> GetListByFilterAsync(UserFilterDto filterDto)
    {
        var filter = _mapper.Map<UserFilter>(filterDto);

        var result = await _userService.GetListByFilterAsync(filter);

        var paginationDto = _mapper.Map<PaginationDto<UserResponseDTo>>(result);

        return paginationDto;
    }

    public async Task<UserResponseDTo> GetByFilterAsync(UserFilterDto filterDto)
    {
        var filter = _mapper.Map<UserFilter>(filterDto);

        var result = await _userService.GetByFilterAsync(filter);

        var resultDto = _mapper.Map<UserResponseDTo>(result);

        return resultDto;
    }
 
    public async Task<long> CreateAsync(UserRequestDto  userRequestDto)
    {
        var customer = _mapper.Map<User>(userRequestDto);

        var id = await _userService.CreateAsync(customer);

        return id;
    }
     
}