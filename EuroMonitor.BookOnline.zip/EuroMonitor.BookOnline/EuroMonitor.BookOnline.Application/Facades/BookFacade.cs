﻿using AutoMapper;
using EuroMonitor.BookOnline.Application.Dtos;
using EuroMonitor.BookOnline.Application.Facades.Interfaces;
using EuroMonitor.BookOnline.Domain.Entities;
using EuroMonitor.BookOnline.Domain.Interfaces;
using EuroMonitor.BookOnline.Domain.Models;
 

namespace EuroMonitor.BookOnline.Application.Facades;

public class BookFacade : IBookFacade
{
    private readonly IBookService  _bookService;
    private readonly IMapper _mapper;

    public BookFacade(IBookService userService, IMapper mapper)
    {
        _bookService = userService;
        _mapper = mapper;
    }

     

    public async Task<IList<BookResponseDTo>> GetAllAsync()
    {
         
         var result = await _bookService.GetAllAsync();
       
         return  _mapper.Map<IList<BookResponseDTo>>(result);
        
    }
    public async Task<BookResponseDTo> GetByFilterAsync(BookFilter filterDto)
    {
        var filter = _mapper.Map<BookFilter>(filterDto);
        var result = await _bookService.GetByFilterAsync(filter);

        var resultDto = _mapper.Map<BookResponseDTo>(result);

        return resultDto;
    }

}