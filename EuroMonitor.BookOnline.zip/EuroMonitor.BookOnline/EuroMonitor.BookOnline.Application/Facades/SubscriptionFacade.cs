﻿using AutoMapper;
using EuroMonitor.BookOnline.Application.Dtos;
using EuroMonitor.BookOnline.Application.Facades.Interfaces;
using EuroMonitor.BookOnline.Domain.Entities;
using EuroMonitor.BookOnline.Domain.Interfaces;
using EuroMonitor.BookOnline.Domain.Models;
 

namespace EuroMonitor.BookOnline.Application.Facades;

public class SubscriptionFacade : ISubscriptionFacade
{
    private readonly ISubscriptionService _userService;
    private readonly IMapper _mapper;

    public SubscriptionFacade(ISubscriptionService  subscriptionService, IMapper mapper)
    {
        _userService = subscriptionService;
        _mapper = mapper;
    }

    public async Task<PaginationDto<SubscriptionResponseDto>> GetListByFilterAsync(SubscriptionFilterDto filterDto)
    {
        var filter = _mapper.Map<SubscriptionFilter>(filterDto);

        var result = await _userService.GetListByFilterAsync(filter);

        var paginationDto = _mapper.Map<PaginationDto<SubscriptionResponseDto>>(result);

        return paginationDto;
    }

    public async Task<SubscriptionResponseDto> GetByFilterAsync(SubscriptionFilterDto filterDto)
    {
        var filter = _mapper.Map<SubscriptionFilter>(filterDto);

        var result = await _userService.GetByFilterAsync(filter);

        var resultDto = _mapper.Map<SubscriptionResponseDto>(result);

        return resultDto;
    }
 
    //public async Task<long> CreateAsync(UserRequestDto  userRequestDto)
    //{
    //    var customer = _mapper.Map<User>(userRequestDto);

    //    var id = await _userService.CreateAsync(customer);

    //    return id;
    //}
     
}