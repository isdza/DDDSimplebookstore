﻿using EuroMonitor.BookOnline.Application.Dtos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EuroMonitor.BookOnline.Application.Facades.Interfaces
{
    public interface  ISubscriptionFacade
    {

        Task<SubscriptionResponseDto> GetByFilterAsync(SubscriptionFilterDto filterDto);
        Task<PaginationDto<SubscriptionResponseDto>> GetListByFilterAsync(SubscriptionFilterDto filterDto);
     //   Task<long> CreateAsync(SubscriptionRequestDto  subscriptionRequestDto);
    }
}
