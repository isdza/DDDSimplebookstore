﻿using EuroMonitor.BookOnline.Application.Dtos;
using EuroMonitor.BookOnline.Domain.Models;

namespace EuroMonitor.BookOnline.Application.Facades.Interfaces;


    public interface IBookFacade
    {
    Task<BookResponseDTo> GetByFilterAsync(BookFilter filterDto);
    Task<IList<BookResponseDTo>> GetAllAsync();
        
        
    }