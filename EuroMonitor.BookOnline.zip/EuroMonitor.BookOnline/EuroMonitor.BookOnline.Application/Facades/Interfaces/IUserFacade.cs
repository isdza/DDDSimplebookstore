﻿using EuroMonitor.BookOnline.Application.Dtos;
  
namespace EuroMonitor.BookOnline.Application.Facades.Interfaces;


    public interface IUserFacade
    {
        Task<UserResponseDTo> GetByFilterAsync(UserFilterDto filterDto);
        Task<PaginationDto<UserResponseDTo>> GetListByFilterAsync(UserFilterDto filterDto);
        Task<long> CreateAsync(UserRequestDto userRequestDto);
        
    }