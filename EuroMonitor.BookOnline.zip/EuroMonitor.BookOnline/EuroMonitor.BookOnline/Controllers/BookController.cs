using CorrelationId.Abstractions;
using EuroMonitor.BookOnline.Application.Dtos;
using EuroMonitor.BookOnline.Application.Facades;
using EuroMonitor.BookOnline.Application.Facades.Interfaces;
using EuroMonitor.BookOnline.Domain.Models;
using Microsoft.AspNetCore.Mvc;
using Swashbuckle.AspNetCore.Annotations;
using System.ComponentModel.DataAnnotations;
using System.Net;

namespace EuroMonitor.BookOnline.Controllers;

[ApiController]
[Route("api/v1/book")]
public class BookController : ControllerBase
{
    private readonly ICorrelationContextAccessor _correlationContext;
    private readonly IBookFacade  _bookFacade;
    private readonly ILogger _logger;

    public BookController(ICorrelationContextAccessor correlationContext, 
        ILogger<BookController> logger,
        IBookFacade bookFacade)
    {
        _logger = logger;
        _correlationContext = correlationContext;
        _bookFacade = bookFacade;
    }

     

    [HttpGet]
 
    //[SwaggerResponse((int)HttpStatusCode.OK, "User successfully returned.")]
    //public async Task<IList<BookResponseDTo>> Get()
    //{
    //    try
    //    {
    //       //  if (id <= 0) return BadRequest(CreateProblemDetails("Id", "Invalid Id."));

    //       // var filter = new UserFilterDto { Id = id };
    //        var result = await _bookFacade.GetAllAsync();

    //        //if (result == null) return NotFound();

    //        return result;
    //    }
    //    catch (ValidationException e)
    //    {
    //        _logger.LogError(e, "Validation Exception. CorrelationId: {correlationId}",
    //            _correlationContext.CorrelationContext.CorrelationId);
    //        return null;
    //       // return BadRequest(e.Message);
    //    }
    //}
    [SwaggerResponse((int)HttpStatusCode.OK, "User successfully returned.")]
    public async Task<IActionResult> Get()
    {
        try
        {
            //  if (id <= 0) return BadRequest(CreateProblemDetails("Id", "Invalid Id."));

            // var filter = new UserFilterDto { Id = id };
            var result = await _bookFacade.GetAllAsync();

            if (result == null) return NotFound();

            return Ok(result);
        }
        catch (ValidationException e)
        {
            _logger.LogError(e, "Validation Exception. CorrelationId: {correlationId}",
                _correlationContext.CorrelationContext.CorrelationId);
            
            return BadRequest(e.Message);
        }
    }
    [HttpGet("{id}")]
    [SwaggerResponse((int)HttpStatusCode.BadRequest, "Invalid id.")]
    [SwaggerResponse((int)HttpStatusCode.NotFound, "Book not found.")]
    [SwaggerResponse((int)HttpStatusCode.OK, "Book successfully returned.")]
    public async Task<ActionResult<BookResponseDTo>> Get(long id)
    {
        try
        {
            if (id <= 0) return BadRequest(CreateProblemDetails("Id", "Invalid Id."));

            var filter = new BookFilter { Id = id };
            var result = await _bookFacade.GetByFilterAsync(filter);

            if (result == null) return NotFound();

            return result;
        }
        catch (ValidationException e)
        {
            _logger.LogError(e, "Validation Exception. CorrelationId: {correlationId}",
                _correlationContext.CorrelationContext.CorrelationId);

            return BadRequest(e.Message);
        }
    }

    private static ProblemDetails CreateProblemDetails(string property, string errorMessage)
    {
        var error = new KeyValuePair<string, object>("Errors", new Dictionary<string, List<string>>
            {
                {property, new List<string> {errorMessage}}
            }
        );

        return new ProblemDetails
        {
            Extensions = { error },
            Title = "One validation error occurred.",
            Status = StatusCodes.Status400BadRequest,
            Type = "https://datatracker.ietf.org/doc/html/rfc7231#section-6.5.1"
        };
    }





}