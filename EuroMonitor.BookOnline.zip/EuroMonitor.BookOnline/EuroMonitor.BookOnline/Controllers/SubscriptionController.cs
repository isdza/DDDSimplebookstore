using CorrelationId.Abstractions;
using EuroMonitor.BookOnline.Application.Dtos;
using EuroMonitor.BookOnline.Application.Facades.Interfaces;
using Microsoft.AspNetCore.Mvc;
using Swashbuckle.AspNetCore.Annotations;
using System.ComponentModel.DataAnnotations;
using System.Net;

namespace EuroMonitor.BookOnline.Controllers;

[ApiController]
[Route("api/v1/subscription")]
public class SubscriptionController : ControllerBase
{
    private readonly ICorrelationContextAccessor _correlationContext;
    private readonly ISubscriptionFacade   _subscriptionFacade;
    private readonly ILogger _logger;

    public SubscriptionController(ICorrelationContextAccessor correlationContext, ILogger<SubscriptionController> logger,
        ISubscriptionFacade  subscriptionFacade)
    {
        _logger = logger;
        _correlationContext = correlationContext;
        _subscriptionFacade = subscriptionFacade;
    }

    [HttpGet]
    [SwaggerResponse((int)HttpStatusCode.OK, "subscriptionsuccessfully returned.",
        typeof(PaginationDto<SubscriptionResponseDto>))]
    public async Task<ActionResult<PaginationDto<SubscriptionResponseDto>>> Get(
        [FromQuery] SubscriptionFilterDto   subscriptionFilterDto)
    {
        try
        {
            var result = await _subscriptionFacade.GetListByFilterAsync(subscriptionFilterDto);
            return result;
        }
        catch (ValidationException e)
        {
            _logger.LogError(e, "Validation Exception Details. CorrelationId: {correlationId}",
                _correlationContext.CorrelationContext.CorrelationId);

            return BadRequest(e.Message);
        }
    }

    [HttpGet("{id}")]
    [SwaggerResponse((int)HttpStatusCode.BadRequest, "Invalid id.")]
    [SwaggerResponse((int)HttpStatusCode.NotFound, "subsc not found.")]
    [SwaggerResponse((int)HttpStatusCode.OK, "Subsc successfully returned.")]
    public async Task<ActionResult<SubscriptionResponseDto>> Get(long id)
    {
        try
        {
            if (id <= 0) return BadRequest(CreateProblemDetails("Id", "Invalid Id."));

            var filter = new SubscriptionFilterDto { Id = id };
            var result = await _subscriptionFacade.GetByFilterAsync(filter);

            if (result == null) return NotFound();

            return result;
        }
        catch (ValidationException e)
        {
            _logger.LogError(e, "Validation Exception. CorrelationId: {correlationId}",
                _correlationContext.CorrelationContext.CorrelationId);

            return BadRequest(e.Message);
        }
    }

     

    
     
    private static ProblemDetails CreateProblemDetails(string property, string errorMessage)
    {
        var error = new KeyValuePair<string, object>("Errors", new Dictionary<string, List<string>>
            {
                {property, new List<string> {errorMessage}}
            }
        );

        return new ProblemDetails
        {
            Extensions = { error },
            Title = "One validation error occurred.",
            Status = StatusCodes.Status400BadRequest,
            Type = "https://datatracker.ietf.org/doc/html/rfc7231#section-6.5.1"
        };
    }
}