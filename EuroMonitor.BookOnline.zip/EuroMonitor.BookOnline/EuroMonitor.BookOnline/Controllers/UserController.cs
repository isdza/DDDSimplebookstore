using CorrelationId.Abstractions;
using EuroMonitor.BookOnline.Application.Dtos;
using EuroMonitor.BookOnline.Application.Facades.Interfaces;
using Microsoft.AspNetCore.Mvc;
using Swashbuckle.AspNetCore.Annotations;
using System.ComponentModel.DataAnnotations;
using System.Net;

namespace EuroMonitor.BookOnline.Controllers;

[ApiController]
[Route("api/v1/user")]
public class UserController : ControllerBase
{
    private readonly ICorrelationContextAccessor _correlationContext;
    private readonly IUserFacade  _userFacade;
    private readonly ILogger _logger;

    public UserController(ICorrelationContextAccessor correlationContext, ILogger<UserController> logger,
        IUserFacade  userFacade)
    {
        _logger = logger;
        _correlationContext = correlationContext;
        _userFacade = userFacade;
    }

    [HttpGet]
    [SwaggerResponse((int)HttpStatusCode.OK, "User successfully returned.",
        typeof(PaginationDto<UserResponseDTo>))]
    public async Task<ActionResult<PaginationDto<UserResponseDTo>>> Get(
        [FromQuery] UserFilterDto  userFilterDto)
    {
        try
        {
             
            var result = await _userFacade.GetListByFilterAsync(userFilterDto);
            return result;
        }
        catch (ValidationException e)
        {
            _logger.LogError(e, "Validation Exception Details. CorrelationId: {correlationId}",
                _correlationContext.CorrelationContext.CorrelationId);

            return BadRequest(e.Message);
        }
    }

    [HttpGet("{id}")]
    [SwaggerResponse((int)HttpStatusCode.BadRequest, "Invalid id.")]
    [SwaggerResponse((int)HttpStatusCode.NotFound, "User not found.")]
    [SwaggerResponse((int)HttpStatusCode.OK, "User successfully returned.")]
    public async Task<ActionResult<UserResponseDTo>> Get(long id)
    {
        try
        {
            if (id <= 0) return BadRequest(CreateProblemDetails("Id", "Invalid Id."));

            var filter = new UserFilterDto { Id = id };
            var result = await _userFacade.GetByFilterAsync(filter);

            if (result == null) return NotFound();

            return result;
        }
        catch (ValidationException e)
        {
            _logger.LogError(e, "Validation Exception. CorrelationId: {correlationId}",
                _correlationContext.CorrelationContext.CorrelationId);

            return BadRequest(e.Message);
        }
    }

    [HttpPost]
    [SwaggerResponse((int)HttpStatusCode.BadRequest, "Invalid Request.")]
    [SwaggerResponse((int)HttpStatusCode.Created, "User has been created successfully.")]
    public async Task<IActionResult> Post([FromBody] UserRequestDto  userRequestDto)
    {
        if (!ModelState.IsValid) return BadRequest(ModelState);

        var id = await _userFacade.CreateAsync(userRequestDto);

        return CreatedAtAction(nameof(Get), new { id }, new { id });
    }

    [HttpPut("{id}")]
    [SwaggerResponse((int)HttpStatusCode.BadRequest, "Invalid id.")]
    [SwaggerResponse((int)HttpStatusCode.NotFound, "User not found")]
    [SwaggerResponse((int)HttpStatusCode.NoContent, "User has been updated successfully.")]
    public async Task<IActionResult> Put(long id, [FromBody] UserRequestDto  userRequestDto)
    {
        try
        {
            if (!ModelState.IsValid) return BadRequest(ModelState);

            if (id <= 0) return BadRequest(CreateProblemDetails("Id", "Invalid Id."));

            throw new NotImplementedException();
           // return NoContent();
        }
        
        catch (ValidationException e)
        {
            _logger.LogError(e, "Validation Exception. CorrelationId: {correlationId}",
                _correlationContext.CorrelationContext.CorrelationId);

            return BadRequest(e.Message);
        }
    }

    [HttpDelete("{id}")]
    [SwaggerResponse((int)HttpStatusCode.BadRequest, "Invalid id.")]
    [SwaggerResponse((int)HttpStatusCode.NotFound, "User not found.")]
    [SwaggerResponse((int)HttpStatusCode.NoContent, "User has been deleted successfully.")]
    public async Task<IActionResult> Delete(long id)
    {
        try
        {
            if (id <= 0) return BadRequest(CreateProblemDetails("Id", "Invalid Id."));

            throw new NotImplementedException();

            //return NoContent();
        }
        
        catch (ValidationException e)
        {
            _logger.LogError(e, "Validation Exception. CorrelationId: {correlationId}",
                _correlationContext.CorrelationContext.CorrelationId);

            return BadRequest(e.Message);
        }
    }

    private static ProblemDetails CreateProblemDetails(string property, string errorMessage)
    {
        var error = new KeyValuePair<string, object>("Errors", new Dictionary<string, List<string>>
            {
                {property, new List<string> {errorMessage}}
            }
        );

        return new ProblemDetails
        {
            Extensions = { error },
            Title = "One validation error occurred.",
            Status = StatusCodes.Status400BadRequest,
            Type = "https://datatracker.ietf.org/doc/html/rfc7231#section-6.5.1"
        };
    }
}