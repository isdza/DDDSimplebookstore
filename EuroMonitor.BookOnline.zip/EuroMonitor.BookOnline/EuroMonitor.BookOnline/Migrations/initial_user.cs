﻿

using Microsoft.EntityFrameworkCore.Migrations;

namespace EuroMonitor.BookOnline.Web.Migrations
{
    public partial class Customer : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                "User",
                table => new
                {
                    Id = table.Column<long>("bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    
                    Email = table.Column<string>("nvarchar(100)", maxLength: 100, nullable: false),
                    FirstName = table.Column<string>("nvarchar(100)", maxLength: 100, nullable: false),
                    Password = table.Column<string>("nvarchar(2000)", maxLength: 2000, nullable: false),
                    Surname = table.Column<string>("nvarchar(100)", maxLength: 100, nullable: false)
                     
                },
                constraints: table => { table.PrimaryKey("PK_Customer", x => x.Id); });

            migrationBuilder.CreateIndex(
                "IX_User_Email",
                "User",
                "Email",
                unique: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                "User");
        }
    }
}