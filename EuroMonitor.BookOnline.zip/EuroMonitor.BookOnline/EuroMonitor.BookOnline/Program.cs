using CorrelationId.DependencyInjection;
using CorrelationId;
using EuroMonitor.BookOnline.Web.LogMiddleware;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.AspNetCore.ResponseCompression;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.OpenApi.Models;
using Swashbuckle.AspNetCore.SwaggerGen;
using System.IO.Compression;
using EuroMonitor.BookOnline.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;
using NLog;
using NLog.Extensions.Logging;
using NLog.Web;
using EuroMonitor.BookOnline.Application.Facades.Interfaces;
using EuroMonitor.BookOnline.Application.Facades;
using EuroMonitor.BookOnline.Domain.Interfaces;
using EuroMonitor.BookOnline.Domain.Services;
using EuroMonitor.BookOnline.Domain.Repositories;
using EuroMonitor.BookOnline.Infrastructure.Repositories;
using EuroMonitor.BookOnline.Domain.Services.Interfaces;
using EuroMonitor.BookOnline.Infrastructure.Mappers;
using LogLevel = Microsoft.Extensions.Logging.LogLevel;
using Microsoft.AspNetCore.Authentication.JwtBearer;

var builder = WebApplication.CreateBuilder(args);

builder.Host.UseNLog();

//builder.Services.AddControllers(x => x.Filters.Add<ExceptionFilter>());
builder.Services.AddControllers();
 
//?? new code
builder.Services.AddAuthentication()
  .AddJwtBearer()
  .AddJwtBearer("LocalAuthIssuer");


builder.Services.AddAuthorization();

builder.Services.AddProblemDetails();
builder.Services.AddDefaultCorrelationId(ConfigureCorrelationId());
//builder.Services.AddTransient<IUserFacade, UserFacade>();
//builder.Services.AddTransient<IUserService, UserService>();
//builder.Services.AddTransient<IUserRepository, UserRepository>();
builder.Services.AddSingleton<IPasswordCryptService, PasswordCryptService>();


builder.Services.AddTransient<IBookFacade, BookFacade>();
builder.Services.AddTransient<IUserFacade, UserFacade>();
builder.Services.AddTransient<ISubscriptionFacade, SubscriptionFacade>();

builder.Services.AddTransient<IBookService, BookService>();
builder.Services.AddTransient<IUserService, UserService>();
builder.Services.AddTransient<ISubscriptionService, SubscriptionService>();


builder.Services.AddTransient<IBookRepository, BookRepository>();
builder.Services.AddTransient<IUserRepository, UserRepository>();
builder.Services.AddTransient<ISuscriptionRepository, SuscriptionRepository>();

builder.Services.AddAutoMapper(typeof(UserProfile));
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(SetupSwagger());
builder.Services.Configure<GzipCompressionProviderOptions>(options => options.Level = CompressionLevel.Optimal);
builder.Services.AddResponseCompression(options => { options.Providers.Add<GzipCompressionProvider>(); });
builder.Services.AddDbContext<UserContext>(options =>
{
    options.UseSqlServer(builder.Configuration.GetConnectionString("DbConnection"));
        //a => { a.MigrationsAssembly("EuroMonitor.BookOnline.Web"); });
});

builder.Services.AddDbContext<BookContext>(options =>
{
    options.UseSqlServer(builder.Configuration.GetConnectionString("DbConnection"));
    //a => { a.MigrationsAssembly("EuroMonitor.BookOnline.Web"); });
});


builder.Services.AddDbContext<SubscriptionContext>(options =>
{
    options.UseSqlServer(builder.Configuration.GetConnectionString("DbConnection"));
    //a => { a.MigrationsAssembly("EuroMonitor.BookOnline.Web"); });
});



AddNLog();

await using var app = builder.Build();

//RunMigration();
app.UseCorrelationId();
AddExceptionHandler();
AddSwagger();
app.UseMiddleware<LogExceptionMiddleware>();
app.UseMiddleware<LogRequestMiddleware>();
app.UseMiddleware<LogResponseMiddleware>();
app.UseHttpsRedirection();

app.UseCors();
app.UseAuthentication();
app.UseAuthorization();

app.MapControllers();

await app.RunAsync();

void AddExceptionHandler()
{
    if (app.Environment.IsDevelopment()) return;
    app.UseExceptionHandler(ConfigureExceptionHandler());
}

void AddSwagger()
{
    if (!app.Environment.IsDevelopment()) return;
    app.UseSwagger();
    app.UseSwaggerUI(c => c.SwaggerEndpoint("/swagger/v1/swagger.json", "EuroMonitor.BookOnline (Imed Tag) API"));
}

void AddNLog()
{
    if (builder.Environment.EnvironmentName.Contains("Test")) return;
    LogManager.Setup().LoadConfigurationFromSection(builder.Configuration);
}

Action<SwaggerGenOptions> SetupSwagger()
{
    return c =>
    {
        c.SwaggerDoc("v1", new OpenApiInfo { Title = "EuroMonitor.BookOnline (Imed Tag) API", Version = "v1" });

        c.CustomSchemaIds(x => x.FullName);

        c.AddSecurityDefinition("Authorization", new OpenApiSecurityScheme
        {
            Type = SecuritySchemeType.Http,
            Scheme = "bearer",
            Description = "JWT Authorization header using the Bearer scheme",
            In = ParameterLocation.Header
        });

        c.AddSecurityRequirement(new OpenApiSecurityRequirement
        {
            {
                new OpenApiSecurityScheme
                {
                    Reference = new OpenApiReference
                    {
                        Type = ReferenceType.SecurityScheme,
                        Id = "Authorization"
                    }
                },
                new List<string>()
            }
        });
    };
}

Action<CorrelationIdOptions> ConfigureCorrelationId()
{
    return options =>
    {
        options.LogLevelOptions = new CorrelationIdLogLevelOptions
        {
            FoundCorrelationIdHeader = Microsoft.Extensions.Logging.LogLevel.Debug,
            MissingCorrelationIdHeader = LogLevel.Debug
        };
    };
}

Action<IApplicationBuilder> ConfigureExceptionHandler()
{
    return exceptionHandlerApp =>
    {
        exceptionHandlerApp.Run(async context =>
        {
            context.Response.StatusCode = StatusCodes.Status500InternalServerError;

            await context.Response.WriteAsJsonAsync(new
            {
                Message = "An unexpected internal exception occurred."
            });
        });
    };
}
 
public partial class Program
{
}