using EuroMonitor.BookOnline.Application.Dtos;
using EuroMonitor.BookOnline.Domain.Repositories;

namespace EuroMonitor.BookOnline.Portal.Models
{
    public class BookViewModel: BookResponseDTo
    {
        public bool Subscribed { get; set; }
    }
}