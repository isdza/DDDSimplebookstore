﻿using EuroMonitor.BookOnline.Application.Dtos;
using EuroMonitor.BookOnline.Domain.Entities;
using EuroMonitor.BookOnline.Portal.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using NLog;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Reflection;
using System.Web;
using System.Web.Mvc;
using WRewards.WebClient.Helper;

namespace EuroMonitor.BookOnline.Portal.Controllers
{
    public class BookController : MVCBaseController
    {
        public BookController(ILogger<MVCBaseController> logger, 
            IHttpClientFactory httpClientFactory, IConfiguration configuration) : base(logger, httpClientFactory, configuration)
        {
        }

        public  async Task<Microsoft.AspNetCore.Mvc.ActionResult> Index()
        {
            // Get books
            string apiUrl = _baseAddress + "book"  ;

            using (HttpClient client = new HttpClient())
            {
                HttpResponseMessage response = await client.GetAsync(apiUrl);

                if (response.IsSuccessStatusCode)
                {
                    string data = await response.Content.ReadAsStringAsync();
                    // Process the data returned by the API
                    // You can deserialize the response JSON into a model or perform any other operations
                    var lst = JsonConvert.DeserializeObject<IList<BookViewModel>>(data);


                    if (lst != null && lst.Count > 0)
                    {
                         
                            return View(lst);
                       
                    }
                    

                    else
                        ModelState.AddModelError("", "no books found in catalog.");
                }
                else
                {
                    // Handle the error if the API request was not successful
                    ModelState.AddModelError("", "request was not successful.");
                }
            }


            return View();
        }
        
        public async Task<Microsoft.AspNetCore.Mvc.ActionResult> Subscription()
        {
             
            // Get books
            string apiUrl = _baseAddress + "book";

            using (HttpClient client = new HttpClient())
            {
                HttpResponseMessage response = await client.GetAsync(apiUrl);

                if (response.IsSuccessStatusCode)
                {
                    string data = await response.Content.ReadAsStringAsync();
                    // Process the data returned by the API
                    // You can deserialize the response JSON into a model or perform any other operations
                    var lst = JsonConvert.DeserializeObject<IList<BookViewModel>>(data);


                    if (lst != null && lst.Count > 0)
                    {
                        
                        if (TempData["UserId"] != null && string.IsNullOrWhiteSpace(TempData["UserId"].ToString()) == false)
                        {
                            
                            string strUserId = TempData["UserId"].ToString();
                            long userId = Convert.ToInt64(strUserId);
                            await PopulateBooksWithUserSubsriptiosCourseData(userId, lst);

                            return View(ViewBag.Books);
                        }
                        else
                            return View(lst);

                    }


                    else
                        ModelState.AddModelError("", "no books found in catalog.");
                }
                else
                {
                    // Handle the error if the API request was not successful
                    ModelState.AddModelError("", "request was not successful.");
                }
            }


            return View();
        }

        public async Task<Microsoft.AspNetCore.Mvc.ActionResult> Details(int? id)
        {
            if (id == null)
            {
                ModelState.AddModelError("", "no book DETAILS found in catalog.");
            }
            

            string apiUrl = _baseAddress + "book" + "/" + id;

            using (HttpClient client = new HttpClient())
            {
                HttpResponseMessage response = await client.GetAsync(apiUrl);

                if (response.IsSuccessStatusCode)
                {
                    string data = await response.Content.ReadAsStringAsync();
                    // Process the data returned by the API
                    // You can deserialize the response JSON into a model or perform any other operations
                    var lst = JsonConvert.DeserializeObject<BookViewModel>(data);


                    if (lst != null )

                        return View(lst);

                    else
                        ModelState.AddModelError("", "no books found in catalog.");
                }
                else
                {
                    // Handle the error if the API request was not successful
                    ModelState.AddModelError("", "request was not successful.");
                }
            }
             
            return View();


        }
        private async Task PopulateBooksWithUserSubsriptiosCourseData(long userId,IList<BookViewModel> books )
        {
            string apiUrl = _baseAddress + "subscription" + "?UserId=" + userId;

            // var subsc=new List<SubscriptionResponseDto>();
            using (HttpClient client = new HttpClient())
            {
                HttpResponseMessage response = await client.GetAsync(apiUrl);

                if (response.IsSuccessStatusCode)
                {
                    string data = await response.Content.ReadAsStringAsync();
                    // Process the data returned by the API
                    // You can deserialize the response JSON into a model or perform any other operations
                    var userBooks = JsonConvert.DeserializeObject<PaginationDto<SubscriptionResponseDto>>(data);
                    if (userBooks != null && userBooks.Result != null)
                    {
                        var mybooks = new HashSet<long>(userBooks.Result.Select(c => c.BookId));
                        var viewModel = new List<BookViewModel>();
                        foreach (var book in books)
                        {
                            viewModel.Add(new BookViewModel
                            {
                                Id = book.Id,
                                Name = book.Name,
                                Text = book.Text,
                                Subscribed = mybooks.Contains(book.Id)

                            }); ;
                        }
                        ViewBag.Books = viewModel;


                    }

                    else
                        ViewBag.Books = null; 


                }
                 
            }
             
           
        }


        [Microsoft.AspNetCore.Mvc.HttpPost]
        [Microsoft.AspNetCore.Mvc.ValidateAntiForgeryToken]
        public IActionResult SaveData(IList<BookViewModel> model)
        {
            if (ModelState.IsValid)
            {
                // Save the data to the database
                // You can access the properties of the model object here
                // For example: model.Name, model.PropertyName

                // Redirect to a success page or return a JSON response
               return View(model);
               
            }
            else
            {
                // Handle validation errors, if any
                // For example, return the view with the model to display validation messages
                //  return View( );
                return RedirectToAction("Subscription", "Book");
            }
        }

        private void UpdateSubscription()
        {

            var vv = ViewBag.Books;
            //if (selectedCourses == null)
            //{
            //    instructorToUpdate.Courses = new List<Course>();
            //    return;
            //}

            //var selectedCoursesHS = new HashSet<string>(selectedCourses);
            //var instructorCourses = new HashSet<int>
            //    (instructorToUpdate.Courses.Select(c => c.CourseID));
            //foreach (var course in db.Courses)
            //{
            //    if (selectedCoursesHS.Contains(course.CourseID.ToString()))
            //    {
            //        if (!instructorCourses.Contains(course.CourseID))
            //        {
            //            instructorToUpdate.Courses.Add(course);
            //        }
            //    }
            //    else
            //    {
            //        if (instructorCourses.Contains(course.CourseID))
            //        {
            //            instructorToUpdate.Courses.Remove(course);
            //        }
            //    }
            //}
        }

        #region Status Codes
        //private static string ErrorCodeToString(MembershipCreateStatus createStatus)
        //{
        //    // See http://go.microsoft.com/fwlink/?LinkID=177550 for
        //    // a full list of status codes.
        //    switch (createStatus)
        //    {
        //        case MembershipCreateStatus.DuplicateUserName:
        //            return "User name already exists. Please enter a different user name.";

        //        case MembershipCreateStatus.DuplicateEmail:
        //            return "A user name for that e-mail address already exists. Please enter a different e-mail address.";

        //        case MembershipCreateStatus.InvalidPassword:
        //            return "The password provided is invalid. Please enter a valid password value.";

        //        case MembershipCreateStatus.InvalidEmail:
        //            return "The e-mail address provided is invalid. Please check the value and try again.";

        //        case MembershipCreateStatus.InvalidAnswer:
        //            return "The password retrieval answer provided is invalid. Please check the value and try again.";

        //        case MembershipCreateStatus.InvalidQuestion:
        //            return "The password retrieval question provided is invalid. Please check the value and try again.";

        //        case MembershipCreateStatus.InvalidUserName:
        //            return "The user name provided is invalid. Please check the value and try again.";

        //        case MembershipCreateStatus.ProviderError:
        //            return "The authentication provider returned an error. Please verify your entry and try again. If the problem persists, please contact your system administrator.";

        //        case MembershipCreateStatus.UserRejected:
        //            return "The user creation request has been canceled. Please verify your entry and try again. If the problem persists, please contact your system administrator.";

        //        default:
        //            return "An unknown error occurred. Please verify your entry and try again. If the problem persists, please contact your system administrator.";
        //    }
        //}
        #endregion
    }
}
