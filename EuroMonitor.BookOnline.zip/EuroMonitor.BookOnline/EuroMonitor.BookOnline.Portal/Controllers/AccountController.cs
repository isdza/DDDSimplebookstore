﻿using EuroMonitor.BookOnline.Application.Dtos;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using NLog;
using System.ComponentModel.DataAnnotations;
using System.Net.Http;
using System.Reflection;
using System.Web;
using WRewards.WebClient.Helper;

namespace EuroMonitor.BookOnline.Portal.Controllers
{
    public class AccountController : MVCBaseController
    {
        public AccountController(ILogger<MVCBaseController> logger, IHttpClientFactory httpClientFactory, IConfiguration configuration) : base(logger, httpClientFactory, configuration)
        {
        }

        public ActionResult LogOn(UserFilterDto model, string returnUrl)
        {
             
            return View();
        }

        //
        // POST: /Account/LogOn

        [HttpPost]
        public async Task<ActionResult> LogOnAsync(UserFilterDto model)
        {
            if (ModelState.IsValid)
            {
                string apiUrl = _baseAddress + "user" + "?Email=" + model.Email + "&Password=" + model.Password;

                using (HttpClient client = new HttpClient())
                {
                    HttpResponseMessage response = await client.GetAsync(apiUrl);

                    if (response.IsSuccessStatusCode)
                    {
                        string data = await response.Content.ReadAsStringAsync();
                        // Process the data returned by the API
                        // You can deserialize the response JSON into a model or perform any other operations
                        var lst = JsonConvert.DeserializeObject<PaginationDto<UserResponseDTo>>(data);
                         
                         
                        if (lst!=null &&  lst.Result!=null && lst.Result.Count > 0 && lst.Result[0].Id>0)
                        {
                            
                            TempData["UserId"] = lst.Result[0].Id.ToString() ;

                            //TempDataHelper.Put<long>(TempData, "UserId", lst.Result[0].Id.ToString());
                            //return View("Book");
                            
                            return RedirectToAction("Subscription", "Book");
                             


                        }


                        else
                            ModelState.AddModelError("", "The user name or password provided is incorrect.");
                    }
                    else
                    {
                        // Handle the error if the API request was not successful
                        ModelState.AddModelError("", "The user name or password provided is incorrect.");
                    }
                }

                
            }

            // If we got this far, something failed, redisplay form
            return View(model);
        }

        //
        // GET: /Account/LogOff

        public ActionResult LogOff()
        {
            //FormsAuthentication.SignOut();

            return RedirectToAction("Index", "Home");
        }

        //
        // GET: /Account/Register

        public ActionResult Register()
        {
            return View();
        }

        //
        // POST: /Account/Register

        [HttpPost]
        public async   Task<ActionResult>  Register(UserRequestDto   requestDto)
        {
            if (ModelState.IsValid)
            {
                using (var client = new HttpClient())
                {
                    string apiUrl = _baseAddress + "user" ;
                    client.BaseAddress = new Uri(apiUrl);

                    //HTTP POST
                    var result = await client.PostAsJsonAsync<UserRequestDto>("user", requestDto);
                    
                    
                    if (result.IsSuccessStatusCode)
                    {
                        return RedirectToAction("logOn");
                    }
                    else
                    {
                       // return View(requestDto);
                        ModelState.AddModelError(string.Empty, "Server Error. Please contact support.");
                    }

                }

               

                

            }
            return RedirectToAction("logOn");

        }

         
        
        #region Status Codes
        //private static string ErrorCodeToString(MembershipCreateStatus createStatus)
        //{
        //    // See http://go.microsoft.com/fwlink/?LinkID=177550 for
        //    // a full list of status codes.
        //    switch (createStatus)
        //    {
        //        case MembershipCreateStatus.DuplicateUserName:
        //            return "User name already exists. Please enter a different user name.";

        //        case MembershipCreateStatus.DuplicateEmail:
        //            return "A user name for that e-mail address already exists. Please enter a different e-mail address.";

        //        case MembershipCreateStatus.InvalidPassword:
        //            return "The password provided is invalid. Please enter a valid password value.";

        //        case MembershipCreateStatus.InvalidEmail:
        //            return "The e-mail address provided is invalid. Please check the value and try again.";

        //        case MembershipCreateStatus.InvalidAnswer:
        //            return "The password retrieval answer provided is invalid. Please check the value and try again.";

        //        case MembershipCreateStatus.InvalidQuestion:
        //            return "The password retrieval question provided is invalid. Please check the value and try again.";

        //        case MembershipCreateStatus.InvalidUserName:
        //            return "The user name provided is invalid. Please check the value and try again.";

        //        case MembershipCreateStatus.ProviderError:
        //            return "The authentication provider returned an error. Please verify your entry and try again. If the problem persists, please contact your system administrator.";

        //        case MembershipCreateStatus.UserRejected:
        //            return "The user creation request has been canceled. Please verify your entry and try again. If the problem persists, please contact your system administrator.";

        //        default:
        //            return "An unknown error occurred. Please verify your entry and try again. If the problem persists, please contact your system administrator.";
        //    }
        //}
        #endregion
    }
}
