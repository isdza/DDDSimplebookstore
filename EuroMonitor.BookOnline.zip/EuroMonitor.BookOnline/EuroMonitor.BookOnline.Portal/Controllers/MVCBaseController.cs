﻿using EuroMonitor.BookOnline.Application.Dtos;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace WRewards.WebClient.Helper
{

    public class MVCBaseController : Controller
    {
        public IConfiguration _configuration { get; }

        //public readonly IServiceAgent _serviceAgent;
        public readonly ILogger<MVCBaseController> _logger;

        public readonly HttpClient _httpClient;
        public string _baseAddress;
        public MVCBaseController(ILogger<MVCBaseController> logger, IHttpClientFactory httpClientFactory, IConfiguration configuration)//, IServiceAgent serviceAgent)
        {
            _httpClient = httpClientFactory.CreateClient("EuroMonitorBookonlinePortal");
            _logger = logger;
            _configuration = configuration;
            _baseAddress = _configuration["Endpoints:WebApi"];
        }




        private async Task<T> GetDataAnonymous<T>(string apiURL)
        {

           // HttpResponseMessage result = await _httpClient.GetAsync(_baseAddress + apiURL);
            HttpResponseMessage result = await _httpClient.GetAsync(apiURL);

            return await ProcessResult<T>(result);
        }
        public async Task<T> GetDataAnonymous2<T>(string apiURL)
        {

            // HttpResponseMessage result = await _httpClient.GetAsync(_baseAddress + apiURL);
            HttpResponseMessage result = await _httpClient.GetAsync(_baseAddress + apiURL);

            return await ProcessResult<T>(result);
        }
        private async Task<T> ProcessResult<T>(HttpResponseMessage response)
        {
            string data = await response.Content.ReadAsStringAsync();

            if (response.IsSuccessStatusCode)
            {
                //throw new Exception("This is a test");
                return await Task.Run(() => JsonConvert.DeserializeObject<T>(data));
            }
            else
            {
                _logger.LogError("Error Code: " + response.StatusCode + ". Message: " + data);
                throw new Exception(data);
            }
        }
      















        //private async Task<HttpContent> ConvertDataToHttpContent(object data)
        //{

        //    string content = await Task.Run(() => JsonConvert.SerializeObject(data));
        //    byte[] buffer = await Task.Run(() => System.Text.Encoding.UTF8.GetBytes(content));
        //    ByteArrayContent byteContent = await Task.Run(() => new ByteArrayContent(buffer));

        //    byteContent.Headers.ContentType = new MediaTypeHeaderValue("application/json");
        //    return byteContent;

        //}





    }
}

