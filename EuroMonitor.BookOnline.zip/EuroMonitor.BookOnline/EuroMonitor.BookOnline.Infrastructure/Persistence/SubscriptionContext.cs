﻿using EuroMonitor.BookOnline.Domain.Entities;
using Microsoft.EntityFrameworkCore;
 
namespace EuroMonitor.BookOnline.Infrastructure.Persistence;

public class SubscriptionContext : DbContext
{
    public SubscriptionContext(DbContextOptions<SubscriptionContext> options) : base(options)
    {
    }

    public DbSet<Subscription> Subscriptions { get; set; }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        SubscriptionModelBuilder(modelBuilder);
    }

    private static void SubscriptionModelBuilder(ModelBuilder modelBuilder)
    {
        var model = modelBuilder.Entity<Subscription>();

        model.ToTable("Subscription");

        //model.Property(x => x.Email)
        //    .HasMaxLength(100)
        //    .IsRequired();

        //model.HasIndex(x => x.Email)
        //    .IsUnique();

        //model.Property(x => x.FirstName)
        //    .HasMaxLength(100)
        //    .IsRequired();

        //model.Property(x => x.Password)
        //    .HasMaxLength(100)
        //    .IsRequired();

        //model.Property(x => x.Surname)
        //    .HasMaxLength(100)
        //    .IsRequired();
    }
}