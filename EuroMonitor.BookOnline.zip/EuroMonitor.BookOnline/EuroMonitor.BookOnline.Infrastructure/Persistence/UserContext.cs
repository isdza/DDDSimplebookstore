﻿using EuroMonitor.BookOnline.Domain.Entities;
using Microsoft.EntityFrameworkCore;
 
namespace EuroMonitor.BookOnline.Infrastructure.Persistence;

public class UserContext : DbContext
{
    public UserContext(DbContextOptions<UserContext> options) : base(options)
    {
    }

    public DbSet<User> Users { get; set; }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        UserModelBuilder(modelBuilder);
    }

    private static void UserModelBuilder(ModelBuilder modelBuilder)
    {
        var model = modelBuilder.Entity<User>();

        model.ToTable("User");

        model.Property(x => x.Email)
            .HasMaxLength(100)
            .IsRequired();

        model.HasIndex(x => x.Email)
            .IsUnique();

        model.Property(x => x.FirstName)
            .HasMaxLength(100)
            .IsRequired();

        model.Property(x => x.Password)
            .HasMaxLength(100)
            .IsRequired();

        model.Property(x => x.Surname)
            .HasMaxLength(100)
            .IsRequired();
    }
}