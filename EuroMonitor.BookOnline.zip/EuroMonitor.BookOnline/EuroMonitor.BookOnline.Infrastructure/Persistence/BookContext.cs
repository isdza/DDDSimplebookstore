﻿using EuroMonitor.BookOnline.Domain.Entities;
using Microsoft.EntityFrameworkCore;
 

namespace EuroMonitor.BookOnline.Infrastructure.Persistence;

public class BookContext : DbContext
{
    public BookContext(DbContextOptions<BookContext> options) : base(options)
    {
    }

    public DbSet<Book> Books { get; set; }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        BookModelBuilder(modelBuilder);
    }

    private static void BookModelBuilder(ModelBuilder modelBuilder)
    {
        var model = modelBuilder.Entity<Book>();

        model.ToTable("Book");

        //model.Property(x => x.Email)
        //    .HasMaxLength(100)
        //    .IsRequired();

        //model.HasIndex(x => x.Email)
        //    .IsUnique();

        //model.Property(x => x.FirstName)
        //    .HasMaxLength(100)
        //    .IsRequired();

        //model.Property(x => x.Password)
        //    .HasMaxLength(100)
        //    .IsRequired();

        //model.Property(x => x.Surname)
        //    .HasMaxLength(100)
        //    .IsRequired();
    }
}