﻿using EuroMonitor.BookOnline.Domain.Entities;
using EuroMonitor.BookOnline.Domain.Models;
using EuroMonitor.BookOnline.Domain.Repositories;
using EuroMonitor.BookOnline.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;
 

namespace EuroMonitor.BookOnline.Infrastructure.Repositories;
 
 public class SuscriptionRepository : ISuscriptionRepository
{
    protected readonly SubscriptionContext DbContext;
    protected readonly DbSet<Subscription> DbSet;
    public SuscriptionRepository(SubscriptionContext context)
    {
        DbContext = context;
        DbSet = DbContext.Set<Subscription>();
    }

    public void Add(Subscription entity)
    {
        DbSet.Add(entity);
    }


    public virtual async Task AddAsync(Subscription entity)
    {
        await DbSet.AddAsync(entity);
    }

    public virtual async Task<Subscription> GetByIdAsync(long id)
    {
        return await DbSet.FindAsync(id);
    }

    public virtual async Task<IList<Subscription>> GetAllAsync()
    {
        return await DbSet.ToListAsync();
    }

    public virtual void Update(Subscription entity)
    {
        DbSet.Update(entity);
    }

    public virtual void Remove(Subscription entity)
    {
        DbSet.Remove(entity);
    }

    public async Task<int> SaveChangesAsync()
    {
        return await DbContext.SaveChangesAsync();
    }

    public void Dispose()
    {
        DbContext.Dispose();
        GC.SuppressFinalize(this);
    }
    public async Task<int> CountByFilterAsync(SubscriptionFilter filter)
    {
        var query = DbContext.Subscriptions.AsQueryable();

        query = ApplyFilter(filter, query);

        return await query.CountAsync();
    }

    public async Task<Subscription> GetByFilterAsync(SubscriptionFilter filter)
    {
        var query = DbContext.Subscriptions.AsQueryable();

        query = ApplyFilter(filter, query);

        return await query.FirstOrDefaultAsync();
    }

    public async Task<List<Subscription>> GetListByFilterAsync(SubscriptionFilter filter)
    {
        var query = DbContext.Subscriptions.AsQueryable();

        query = ApplyFilter(filter, query);

        query = ApplySorting(filter, query);

        if (filter.CurrentPage > 0)
            query = query.Skip((filter.CurrentPage - 1) * filter.PageSize).Take(filter.PageSize);

        return await query.ToListAsync();
    }

    private static IQueryable<Subscription> ApplySorting(SubscriptionFilter filter,
        IQueryable<Subscription> query)
    {
        query = filter?.OrderBy.ToLower() switch
        {
            "name" => filter.SortBy.ToLower() == "asc"
                ? query.OrderBy(x => x.UserId)
                : query.OrderByDescending(x => x.UserId),
             
             
            _ => query
        };

        return query;
    }

    private static IQueryable<Subscription> ApplyFilter(SubscriptionFilter filter,
        IQueryable<Subscription> query)
    {
        if (filter.Id > 0)
            query = query.Where(x => x.Id == filter.Id);
        if (filter.UserId > 0)
            query = query.Where(x => x.UserId == filter.UserId);
        if (filter.BookId > 0)
            query = query.Where(x => x.BookId == filter.BookId);

          
        return query;
    }
}


