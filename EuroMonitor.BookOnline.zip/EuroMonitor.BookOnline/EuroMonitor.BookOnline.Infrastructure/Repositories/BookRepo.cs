﻿
using EuroMonitor.BookOnline.Domain.Entities;
using EuroMonitor.BookOnline.Domain.Models;
using EuroMonitor.BookOnline.Domain.Repositories;
using EuroMonitor.BookOnline.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;

namespace EuroMonitor.BookOnline.Infrastructure.Repositories;


public class BookRepository :  IBookRepository
{
    protected readonly BookContext DbContext;
    protected readonly DbSet<Book> DbSet;
    public BookRepository(BookContext context)
    {
        DbContext = context;
        DbSet = DbContext.Set<Book>();
    }

    public void Add(Book entity)
    {
        DbSet.Add(entity);
    }

    
    public virtual async Task AddAsync(Book entity)
    {
        await DbSet.AddAsync(entity);
    }

    public virtual async Task<Book> GetByIdAsync(long id)
    {
        return await DbSet.FindAsync(id);
    }

    public virtual async Task<IList<Book>> GetAllAsync()
    {
        return await DbSet.ToListAsync();
    }

    public virtual void Update(Book entity)
    {
        DbSet.Update(entity);
    }

    public virtual void Remove(Book entity)
    {
        DbSet.Remove(entity);
    }

    public async Task<int> SaveChangesAsync()
    {
        return await DbContext.SaveChangesAsync();
    }

    public void Dispose()
    {
        DbContext.Dispose();
        GC.SuppressFinalize(this);
    }
    public async Task<int> CountByFilterAsync(BookFilter filter)
    {
        var query = DbContext.Books.AsQueryable();

        query = ApplyFilter(filter, query);

        return await query.CountAsync();
    }

    public async Task<Book> GetByFilterAsync(BookFilter filter)
    {
        var query = DbContext.Books.AsQueryable();

        query = ApplyFilter(filter, query);

        return await query.FirstOrDefaultAsync();
    }

    public async Task<List<Book>> GetListByFilterAsync(BookFilter filter)
    {
        var query = DbContext.Books.AsQueryable();

        query = ApplyFilter(filter, query);

        query = ApplySorting(filter, query);

        if (filter.CurrentPage > 0)
            query = query.Skip((filter.CurrentPage - 1) * filter.PageSize).Take(filter.PageSize);

        return await query.ToListAsync();
    }

    private static IQueryable<Book> ApplySorting(BookFilter filter,
        IQueryable<Book> query)
    {
        query = filter?.OrderBy.ToLower() switch
        {
            "name" => filter.SortBy.ToLower() == "asc"
                ? query.OrderBy(x => x.Name)
                : query.OrderByDescending(x => x.Name),
             
            _ => query
        };

        return query;
    }

    private static IQueryable<Book> ApplyFilter(BookFilter filter,
        IQueryable<Book> query)
    {
        if (filter.Id > 0)
            query = query.Where(x => x.Id == filter.Id);

        if (!string.IsNullOrWhiteSpace(filter.Name))
            query = query.Where(x => EF.Functions.Like(x.Name, $"%{filter.Name}%"));
   

        return query;
    }
}


