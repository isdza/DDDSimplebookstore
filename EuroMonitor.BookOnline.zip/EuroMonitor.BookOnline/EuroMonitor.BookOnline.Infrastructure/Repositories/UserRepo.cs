﻿
using EuroMonitor.BookOnline.Domain.Entities;
using EuroMonitor.BookOnline.Domain.Models;
using EuroMonitor.BookOnline.Domain.Repositories;
using EuroMonitor.BookOnline.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;

namespace EuroMonitor.BookOnline.Infrastructure.Repositories;


public class UserRepository :  IUserRepository
{
    protected readonly UserContext DbContext;
    protected readonly DbSet<User> DbSet;
    public UserRepository(UserContext context)
    {
        DbContext = context;
        DbSet = DbContext.Set<User>();
    }

    public void Add(User entity)
    {
        DbSet.Add(entity);
    }

    
    public virtual async Task AddAsync(User entity)
    {
        await DbSet.AddAsync(entity);
    }

    public virtual async Task<User> GetByIdAsync(long id)
    {
        return await DbSet.FindAsync(id);
    }

    public virtual async Task<IList<User>> GetAllAsync()
    {
        return await DbSet.ToListAsync();
    }

    public virtual void Update(User entity)
    {
        DbSet.Update(entity);
    }

    public virtual void Remove(User entity)
    {
        DbSet.Remove(entity);
    }

    public async Task<int> SaveChangesAsync()
    {
        return await DbContext.SaveChangesAsync();
    }

    public void Dispose()
    {
        DbContext.Dispose();
        GC.SuppressFinalize(this);
    }
    public async Task<int> CountByFilterAsync(UserFilter filter)
    {
        var query = DbContext.Users.AsQueryable();

        query = ApplyFilter(filter, query);

        return await query.CountAsync();
    }

    public async Task<User> GetByFilterAsync(UserFilter filter)
    {
        var query = DbContext.Users.AsQueryable();

        query = ApplyFilter(filter, query);

        return await query.FirstOrDefaultAsync();
    }

    public async Task<List<User>> GetListByFilterAsync(UserFilter filter)
    {
        var query = DbContext.Users.AsQueryable();

        query = ApplyFilter(filter, query);

        query = ApplySorting(filter, query);

        if (filter.CurrentPage > 0)
            query = query.Skip((filter.CurrentPage - 1) * filter.PageSize).Take(filter.PageSize);

        return await query.ToListAsync();
    }

    private static IQueryable<User> ApplySorting(UserFilter filter,
        IQueryable<User> query)
    {
        query = filter?.OrderBy.ToLower() switch
        {
            "firstname" => filter.SortBy.ToLower() == "asc"
                ? query.OrderBy(x => x.FirstName)
                : query.OrderByDescending(x => x.FirstName),
            "surname" => filter.SortBy.ToLower() == "asc"
                ? query.OrderBy(x => x.Surname)
                : query.OrderByDescending(x => x.Surname),
            "email" => filter.SortBy.ToLower() == "asc"
                ? query.OrderBy(x => x.Email)
                : query.OrderByDescending(x => x.Email),
            _ => query
        };

        return query;
    }

    private static IQueryable<User> ApplyFilter(UserFilter filter,
        IQueryable<User> query)
    {
        if (filter.Id > 0)
            query = query.Where(x => x.Id == filter.Id);

        if (!string.IsNullOrWhiteSpace(filter.FirstName))
            query = query.Where(x => EF.Functions.Like(x.FirstName, $"%{filter.FirstName}%"));

        if (!string.IsNullOrWhiteSpace(filter.Surname))
            query = query.Where(x => EF.Functions.Like(x.Surname, $"%{filter.Surname}%"));

        if (!string.IsNullOrWhiteSpace(filter.Password))
            query = query.Where(x => EF.Functions.Like(x.Password, $"%{filter.Password}%"));

        if (!string.IsNullOrWhiteSpace(filter.Email))
            query = query.Where(x => x.Email == filter.Email);

        return query;
    }
}


