﻿

using AutoMapper;
using EuroMonitor.BookOnline.Application.Dtos;
using EuroMonitor.BookOnline.Domain.Entities;
using EuroMonitor.BookOnline.Domain.Models;

namespace EuroMonitor.BookOnline.Infrastructure.Mappers;

public class UserProfile : Profile
{
    public UserProfile()
    {
        CreateUserProfile();
        CreateBookProfile();
        CreatSubscriptionProfile();
    }
    private void CreatSubscriptionProfile()
    {



        CreateMap<Subscription, SubscriptionResponseDto>();
        //  .ForMember(dest => dest.Id, opt => opt.Ignore())
        // .AfterMap((source, destination) => { destination.id = source.GetFullName(); });

        CreateMap<SubscriptionFilterDto, SubscriptionFilter>();

        CreateMap<Pagination<Subscription>, PaginationDto<SubscriptionResponseDto>>()
            .AfterMap((source, converted, context) =>
            {
                converted.Result = context.Mapper.Map<List<SubscriptionResponseDto>>(source.Result);
            });
    }
    private void CreateBookProfile()
    {
         


        CreateMap<Book, BookResponseDTo>();
        //  .ForMember(dest => dest.Id, opt => opt.Ignore())
        // .AfterMap((source, destination) => { destination.id = source.GetFullName(); });

        //CreateMap<BookFilterDto, BookFilter>();

        CreateMap<Pagination<Book>, PaginationDto<BookResponseDTo>>()
            .AfterMap((source, converted, context) =>
            {
                converted.Result = context.Mapper.Map<List<BookResponseDTo>>(source.Result);
            });
    }

    private void CreateUserProfile()
    {
        CreateMap<UserRequestDto, User>()
            .ForMember(dest => dest.Id, opt => opt.Ignore());


        CreateMap<User, UserResponseDTo>();
          //  .ForMember(dest => dest.Id, opt => opt.Ignore())
           // .AfterMap((source, destination) => { destination.id = source.GetFullName(); });

        CreateMap<UserFilterDto, UserFilter>();

        CreateMap<Pagination<User>, PaginationDto<UserResponseDTo>>()
            .AfterMap((source, converted, context) =>
            {
                converted.Result = context.Mapper.Map<List<UserResponseDTo>>(source.Result);
            });
    }
}